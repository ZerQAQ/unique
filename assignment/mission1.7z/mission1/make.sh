g++ server.cpp -o server.exe
./server.exe