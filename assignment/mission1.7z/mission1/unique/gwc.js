
function addOne(){
	let obj_name = document.getElementById("obj-name");
	let list  = document.getElementById("list");
	let elm = document.createElement("li");
}